package com.example.misdoctr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.misdoctr.DoctorRegActivity;

public class LoginActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Instatiate UI elements
        EditText MedtTxtUserName=(EditText)findViewById(R.id.edtxtUserName);
        EditText MedtTxtPassword=(EditText)findViewById(R.id.edtxtPassword);
        Button MbtnLogin=(Button)findViewById(R.id.button);
        TextView MtxtNewUser=(TextView)findViewById(R.id.txtNewUser);
    }

    public void OpenReg(View view) {
        //To Navigate from one zctivity to another activity
        Intent reg= new Intent(LoginActivity.this, DoctorRegActivity.class);
        startActivity(reg);
    }

      public void Login(View view) {
        startActivity(new Intent(this,DoctorRegActivity.class));
    }
}
