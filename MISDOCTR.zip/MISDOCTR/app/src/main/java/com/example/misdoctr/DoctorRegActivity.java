package com.example.misdoctr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.AndroidException;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.BackgroundActivity;
import com.example.misdoctr.database.DataBaseHelper;

public class DoctorRegActivity extends AppCompatActivity {
    Button getMbtnAdd;
    EditText getMedtTxtDoctorName, getMedtTxtPhone, getMedtTxtEmail, getEditPassword, getEditConfirmPassword;
    RadioButton getMrdoMale, getMrdoFemale;
    Spinner getMspnCountry;
    //create an Object of Doctor Reg UI
    String MedtTxtDoctorName;
    String MedtTxtPhone;
    String MedtTxtEmail;
    String editPassword;
    String editConfirmPassword;
    String MrdoMale;
    String MrdoFemale;
    String MspnCountry;
    Button MbtnAdd;
    //Data source for country
    String Countries[] = {"India", "Rwanda", "Congo", "Uganda", "Tanzania"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_reg);
        MedtTxtDoctorName = String.valueOf((EditText) findViewById(R.id.MedtTxtDoctorName));
        MedtTxtPhone = String.valueOf((EditText) findViewById(R.id.MedtTxtPhone));
        MedtTxtEmail = String.valueOf((EditText) findViewById(R.id.MedtTxtEmail));
        editPassword = String.valueOf((EditText) findViewById(R.id.editPassword));
        editConfirmPassword = String.valueOf((EditText) findViewById(R.id.editConfirmPassword));
        MrdoMale = String.valueOf((RadioButton) findViewById(R.id.rdoMale));
        MrdoFemale = String.valueOf((RadioButton) findViewById(R.id.rdoFemale));
        MbtnAdd = (Button) findViewById(R.id.btnAdd);
        MspnCountry = String.valueOf((Spinner) findViewById(R.id.spnCountry));
        //Initialize the ArrayAdapter with countries data source
        ArrayAdapter<String> countries = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Countries);
        //Setting up Country Spinner with Adapter
        ;
    }



    public void addInfo(View view) {
        MedtTxtDoctorName = getMedtTxtDoctorName.getText().toString();
        MedtTxtPhone =getMedtTxtPhone.getText().toString();
        MedtTxtEmail = getMedtTxtEmail.getText().toString();
        editPassword = getEditPassword.getText().toString();
        editConfirmPassword = getEditConfirmPassword.getText().toString();
        MrdoMale = getMrdoMale.getText().toString();
        MrdoFemale = getMrdoFemale.getText().toString();
        MspnCountry = getMspnCountry.getTouchables().toString();
        BackgroundActivity backgroundActivity = new BackgroundActivity(this);
        BackgroundActivity.SERIAL_EXECUTOR("add_Inform",MedtTxtDoctorName,
                MedtTxtPhone, MedtTxtEmail, editPassword,
                editConfirmPassword, MrdoMale, MrdoFemale, MspnCountry);
        finish();
    }
}
