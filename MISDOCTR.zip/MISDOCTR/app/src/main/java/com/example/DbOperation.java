package com.example;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.core.app.ComponentActivity;

import com.example.misdoctr.DoctorRegActivity;
import com.example.misdoctr.database.DataBaseHelper;

public class DbOperation extends SQLiteOpenHelper {
    private static final int no_VERSION=1;
    private static final String DO_NAME= "Doctor.db";
    private static final String CREATE_QUERY = "Create Table" + DataBaseHelper.Details.TABLE_NAME+
            "("+DataBaseHelper.Details.MedtTxtDoctorName+ "text,"+ DataBaseHelper.Details.MedtTxtPhone+ "text,"+
            DataBaseHelper.Details.MedtTxtEmail+ "text,"+ DataBaseHelper.Details.editPassword+ "text,"+
            DataBaseHelper.Details.editConfirmPassword+ "text,"+DataBaseHelper.Details.MrdoMale+ "text,"+
            DataBaseHelper.Details.MrdoFemale+ "text,"+DataBaseHelper.Details.MspnCountry+ "text)";
    public DbOperation(Context ctx)
    {
        super(ctx,DO_NAME,null,no_VERSION);
        Log.d("Database Operation","Database Created");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.d("Database Operation","Table Created");

    }
    public void addInfo(SQLiteDatabase db,String MedtTxtDoctorName,String MedtTxtPhone,String MedtTxtEmail,String editPassword,
                        String editConfirmPassword,String MrdoMale,String MrdoFemale,String MspnCountry)
    {

        ContentValues contentValues = new ContentValues();
        contentValues.put(DataBaseHelper.Details.MedtTxtDoctorName,MedtTxtDoctorName);
        contentValues.put(DataBaseHelper.Details.MedtTxtPhone,MedtTxtPhone);
        contentValues.put(DataBaseHelper.Details.MedtTxtEmail,MedtTxtEmail);
        contentValues.put(DataBaseHelper.Details.editPassword,editPassword);
        contentValues.put(DataBaseHelper.Details.editConfirmPassword,editConfirmPassword);
        contentValues.put(DataBaseHelper.Details.MrdoMale,MrdoMale);
        contentValues.put(DataBaseHelper.Details.MrdoFemale,MrdoFemale);
        contentValues.put(DataBaseHelper.Details.MspnCountry,MspnCountry);
        db.insert(DataBaseHelper.Details.TABLE_NAME,null,contentValues);
        Log.d("Database Operation","Inserted.......");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
