package com.example.misdoctr.database;

public final class DataBaseHelper{
   DataBaseHelper(){}
    public static abstract class  Details
    {
        public static final String MedtTxtDoctorName= "name";
        public static final String  MedtTxtPhone= "Phone";
        public static final String MedtTxtEmail= "email";
        public static final String editPassword= "Password";
        public static final String editConfirmPassword= "password";
        public static final String MrdoMale= "Male";
        public static final String MrdoFemale= "female";
        public static final String  MspnCountry = "country";
        public static final String TABLE_NAME = "doctors";


    }
}