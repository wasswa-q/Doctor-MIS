package com;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.text.PrecomputedText;
import android.widget.Toast;

import androidx.core.text.PrecomputedTextCompat;

import com.example.DbOperation;

import java.lang.reflect.Parameter;

public class BackgroundActivity extends AsyncTask<String,Void,String> {
    Context ctx;
    private String[] Params;

    public BackgroundActivity(Context ctx){

        this.ctx = ctx;
    }

    public static void SERIAL_EXECUTOR(String add_inform, String medtTxtDoctorName, String medtTxtPhone, String medtTxtEmail, String editPassword, String editConfirmPassword, String mrdoMale, String mrdoFemale, String mspnCountry) {

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... voids) {

        String method =Params [0];
        DbOperation dbOperation =new DbOperation(ctx);
        if (method.equals("add_info"))
        {

            String MedtTxtDoctorName = Params[1];
            String  MedtTxtPhone = Params[2];
            String MedtTxtEmail  = Params[3];
            String editPassword = Params[4];
            String  editConfirmPassword = Params[5];
            String  MrdoMale = Params[6];
            String MrdoFemale = Params[7];
            String MspnCountry = Params[8];

            SQLiteDatabase db = dbOperation.getWritableDatabase();
            dbOperation.addInfo(db,MedtTxtDoctorName,MedtTxtPhone,MedtTxtEmail,editPassword,editConfirmPassword,MrdoMale,MrdoFemale,MspnCountry);
            return "Inserted.....";
        }

        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String result) {
        Toast.makeText(ctx,result,Toast.LENGTH_LONG).show();
    }
}
